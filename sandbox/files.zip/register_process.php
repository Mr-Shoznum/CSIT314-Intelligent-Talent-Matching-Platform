<?php
/**
 * register_process.php
 * Handles POST from register.php via fetch().
 * Returns JSON: { success: bool, message: string, redirect?: string }
 *
 * Password security: PHP password_hash() with PASSWORD_BCRYPT (cost 12)
 */

header('Content-Type: application/json');

// ── Only accept POST ────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

require_once 'db.php';

// ── Helpers ─────────────────────────────────────────────────────────────────
function clean(string $val): string {
    return htmlspecialchars(strip_tags(trim($val)), ENT_QUOTES, 'UTF-8');
}

function respond(bool $success, string $message, string $redirect = ''): void {
    $payload = ['success' => $success, 'message' => $message];
    if ($redirect) $payload['redirect'] = $redirect;
    echo json_encode($payload);
    exit;
}

// ── Collect & sanitise inputs ────────────────────────────────────────────────
$account_type = in_array($_POST['account_type'] ?? '', ['candidate', 'company'])
    ? $_POST['account_type']
    : 'candidate';

$email    = clean($_POST['email']    ?? '');
$phone    = clean($_POST['phone']    ?? '');
$password = $_POST['password']       ?? '';
$confirm  = $_POST['password_confirm'] ?? '';

// ── Server-side validation ───────────────────────────────────────────────────
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(false, 'Please enter a valid email address.');
}

if (strlen($password) < 8) {
    respond(false, 'Password must be at least 8 characters.');
}

if ($password !== $confirm) {
    respond(false, 'Passwords do not match.');
}

// Type-specific fields
if ($account_type === 'candidate') {
    $first_name = clean($_POST['first_name'] ?? '');
    $last_name  = clean($_POST['last_name']  ?? '');

    if (empty($first_name) || empty($last_name)) {
        respond(false, 'Please enter your first and last name.');
    }
} else {
    $company_name = clean($_POST['company_name'] ?? '');
    $abn          = preg_replace('/\s+/', '', clean($_POST['abn'] ?? ''));

    if (empty($company_name)) {
        respond(false, 'Please enter your company name.');
    }

    // ABN validation — 11 digits if provided
    if ($abn !== '' && (!preg_match('/^\d{11}$/', $abn) || !validateABN($abn))) {
        respond(false, 'Please enter a valid 11-digit ABN.');
    }
}

// ── Check for duplicate email ────────────────────────────────────────────────
$db   = getDB();
$stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->close();
    respond(false, 'An account with that email already exists.');
}
$stmt->close();

// ── Hash password (bcrypt, cost 12) ─────────────────────────────────────────
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

// ── Insert into users ────────────────────────────────────────────────────────
$db->begin_transaction();

try {
    $stmt = $db->prepare(
        'INSERT INTO users (account_type, email, password_hash, phone)
         VALUES (?, ?, ?, ?)'
    );
    $phoneVal = $phone ?: null;
    $stmt->bind_param('ssss', $account_type, $email, $hash, $phoneVal);
    $stmt->execute();
    $user_id = $db->insert_id;
    $stmt->close();

    // ── Insert profile row ────────────────────────────────────────────────
    if ($account_type === 'candidate') {
        $stmt = $db->prepare(
            'INSERT INTO candidate_profiles (user_id, first_name, last_name)
             VALUES (?, ?, ?)'
        );
        $stmt->bind_param('iss', $user_id, $first_name, $last_name);
    } else {
        $abnVal = $abn ?: null;
        $stmt = $db->prepare(
            'INSERT INTO company_profiles (user_id, company_name, abn)
             VALUES (?, ?, ?)'
        );
        $stmt->bind_param('iss', $user_id, $company_name, $abnVal);
    }

    $stmt->execute();
    $stmt->close();

    $db->commit();

    // TODO: send verification email here

    respond(true, 'Account created successfully.', 'login.php?registered=1');

} catch (Exception $e) {
    $db->rollback();
    // Log the real error server-side, return generic message to client
    error_log('Registration error: ' . $e->getMessage());
    respond(false, 'Registration failed. Please try again later.');
}

// ── ABN Checksum validation ──────────────────────────────────────────────────
/**
 * Validates an Australian Business Number using the official ATO algorithm.
 * @param string $abn  — 11 raw digits, no spaces
 */
function validateABN(string $abn): bool {
    if (strlen($abn) !== 11) return false;

    $weights = [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19];
    $sum = 0;

    for ($i = 0; $i < 11; $i++) {
        $digit = (int)$abn[$i];
        if ($i === 0) $digit--; // subtract 1 from first digit
        $sum += $digit * $weights[$i];
    }

    return ($sum % 89) === 0;
}
