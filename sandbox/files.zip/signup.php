<?php
$activePage = 'signup';
$pageTitle  = 'Sign Up';
include 'header.php';
?>

<style>
    body { background: #f0f6ff; }

    .signup-wrap {
        min-height: calc(100vh - var(--nav-height));
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 60px 24px;
    }

    .signup-card {
        background: #fefefe;
        border: 1px solid #dce8f5;
        border-radius: 20px;
        padding: 52px 48px;
        width: 100%;
        max-width: 580px;
        text-align: center;
        box-shadow: 0 8px 40px rgba(10, 87, 169, 0.08);
    }

    .signup-card__eyebrow {
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        color: #3b9eff;
        margin-bottom: 12px;
    }

    .signup-card__title {
        font-family: 'Syne', sans-serif;
        font-size: 1.9rem;
        font-weight: 800;
        color: #0d1b2e;
        margin-bottom: 10px;
    }

    .signup-card__sub {
        font-size: 0.92rem;
        color: #5c6b7e;
        line-height: 1.6;
        margin-bottom: 40px;
    }

    /* ── Type cards ── */
    .type-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
        margin-bottom: 36px;
    }

    .type-card {
        border: 2px solid #dce8f5;
        border-radius: 14px;
        padding: 28px 20px;
        cursor: pointer;
        text-decoration: none;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 12px;
        transition: border-color 0.2s, box-shadow 0.2s, transform 0.2s;
        color: inherit;
    }

    .type-card:hover {
        border-color: #3b9eff;
        box-shadow: 0 6px 24px rgba(10, 87, 169, 0.12);
        transform: translateY(-3px);
    }

    .type-card__icon {
        width: 60px; height: 60px;
        border-radius: 16px;
        display: flex; align-items: center; justify-content: center;
        font-size: 1.7rem;
    }

    .type-card--candidate .type-card__icon {
        background: linear-gradient(135deg, #e8f4ff, #c3e0ff);
    }

    .type-card--company .type-card__icon {
        background: linear-gradient(135deg, #e8fff2, #b8f0d4);
    }

    .type-card__label {
        font-family: 'Syne', sans-serif;
        font-weight: 700;
        font-size: 1rem;
        color: #0d1b2e;
    }

    .type-card__desc {
        font-size: 0.8rem;
        color: #6b7a8d;
        line-height: 1.5;
        text-align: center;
    }

    .type-card__arrow {
        margin-top: 4px;
        font-size: 1.1rem;
        color: #3b9eff;
        opacity: 0;
        transform: translateX(-4px);
        transition: opacity 0.2s, transform 0.2s;
    }

    .type-card:hover .type-card__arrow {
        opacity: 1;
        transform: translateX(0);
    }

    .signup-card__login {
        font-size: 0.875rem;
        color: #6b7a8d;
    }

    .signup-card__login a {
        color: #0a57a9;
        font-weight: 600;
        text-decoration: none;
    }

    .signup-card__login a:hover { text-decoration: underline; }

    @media (max-width: 480px) {
        .signup-card { padding: 36px 24px; }
        .type-grid { grid-template-columns: 1fr; }
    }
</style>

<div class="signup-wrap">
    <div class="signup-card">
        <p class="signup-card__eyebrow">Create Account</p>
        <h1 class="signup-card__title">Who are you?</h1>
        <p class="signup-card__sub">Choose the account type that best describes you.<br>You can always update your profile later.</p>

        <div class="type-grid">
            <a href="register.php?type=candidate" class="type-card type-card--candidate">
                <div class="type-card__icon">🧑‍💼</div>
                <div class="type-card__label">Candidate</div>
                <p class="type-card__desc">Looking for opportunities or building your professional profile.</p>
                <span class="type-card__arrow">→</span>
            </a>

            <a href="register.php?type=company" class="type-card type-card--company">
                <div class="type-card__icon">🏢</div>
                <div class="type-card__label">Company</div>
                <p class="type-card__desc">Hiring, managing IT projects, or listing opportunities.</p>
                <span class="type-card__arrow">→</span>
            </a>
        </div>

        <p class="signup-card__login">Already have an account? <a href="login.php">Log in</a></p>
    </div>
</div>

</body>
</html>
