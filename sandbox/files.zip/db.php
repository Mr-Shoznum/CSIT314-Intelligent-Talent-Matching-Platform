<?php
/**
 * db.php — Database connection
 * Include this file wherever a DB connection is needed.
 *
 * Setup: create the database and tables by running schema.sql
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // TODO: replace with your MySQL username
define('DB_PASS', '');            // TODO: replace with your MySQL password
define('DB_NAME', 'itmp_db');     // TODO: replace with your database name

function getDB(): mysqli {
    static $conn = null;

    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        if ($conn->connect_error) {
            // In production, log this instead of displaying it
            die(json_encode([
                'success' => false,
                'message' => 'Database connection failed: ' . $conn->connect_error
            ]));
        }

        $conn->set_charset('utf8mb4');
    }

    return $conn;
}
