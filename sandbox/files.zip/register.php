<?php
$activePage = 'signup';
$pageTitle  = 'Create Account';

// Validate the type param — default to candidate if missing/invalid
$type = isset($_GET['type']) && $_GET['type'] === 'company' ? 'company' : 'candidate';

include 'header.php';
?>

<style>
    body { background: #f0f6ff; }

    /* ── Layout ── */
    .register-wrap {
        min-height: calc(100vh - var(--nav-height));
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 60px 24px;
    }

    .register-card {
        background: #fefefe;
        border: 1px solid #dce8f5;
        border-radius: 20px;
        padding: 48px 44px;
        width: 100%;
        max-width: 520px;
        box-shadow: 0 8px 40px rgba(10, 87, 169, 0.08);
    }

    /* ── Progress breadcrumb ── */
    .register-steps {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 32px;
        font-size: 0.78rem;
        font-weight: 500;
        color: #a0b0c4;
    }

    .register-steps__done {
        color: #3b9eff;
        text-decoration: none;
        font-weight: 600;
    }

    .register-steps__done:hover { text-decoration: underline; }

    .register-steps__sep { color: #cdd8e6; }

    .register-steps__current { color: #0d1b2e; font-weight: 600; }

    /* ── Header ── */
    .register-card__badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: <?= $type === 'company' ? 'linear-gradient(135deg,#e8fff2,#b8f0d4)' : 'linear-gradient(135deg,#e8f4ff,#c3e0ff)' ?>;
        color: <?= $type === 'company' ? '#1a7a4a' : '#0a57a9' ?>;
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        padding: 5px 14px;
        border-radius: 20px;
        margin-bottom: 14px;
    }

    .register-card__title {
        font-family: 'Syne', sans-serif;
        font-size: 1.7rem;
        font-weight: 800;
        color: #0d1b2e;
        margin-bottom: 6px;
    }

    .register-card__sub {
        font-size: 0.87rem;
        color: #6b7a8d;
        margin-bottom: 32px;
        line-height: 1.5;
    }

    /* ── Form elements ── */
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
        margin-bottom: 18px;
    }

    .form-group label {
        font-size: 0.82rem;
        font-weight: 600;
        color: #3d4f63;
        letter-spacing: 0.02em;
    }

    .form-group label span {
        color: #e05555;
        margin-left: 2px;
    }

    .form-group input {
        font-family: 'DM Sans', sans-serif;
        font-size: 0.9rem;
        color: #0d1b2e;
        background: #f7fafd;
        border: 1.5px solid #dce8f5;
        border-radius: 8px;
        padding: 11px 14px;
        transition: border-color 0.2s, box-shadow 0.2s;
        outline: none;
        width: 100%;
    }

    .form-group input:focus {
        border-color: #3b9eff;
        box-shadow: 0 0 0 3px rgba(59,158,255,0.12);
        background: #fefefe;
    }

    .form-group input::placeholder { color: #b0bec8; }

    .form-group input.error { border-color: #e05555; }

    .form-group .field-error {
        font-size: 0.75rem;
        color: #e05555;
        display: none;
    }

    /* Password strength */
    .password-wrap { position: relative; }

    .password-toggle {
        position: absolute;
        right: 12px; top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        cursor: pointer;
        color: #8a9ab0;
        font-size: 0.85rem;
        padding: 4px;
        line-height: 1;
    }

    .strength-bar {
        height: 3px;
        border-radius: 3px;
        background: #e4edf7;
        margin-top: 6px;
        overflow: hidden;
    }

    .strength-bar__fill {
        height: 100%;
        border-radius: 3px;
        width: 0%;
        transition: width 0.3s, background 0.3s;
    }

    .strength-label {
        font-size: 0.72rem;
        color: #8a9ab0;
        margin-top: 4px;
    }

    /* Divider */
    .form-divider {
        height: 1px;
        background: #e8f0f9;
        margin: 8px 0 20px;
    }

    .form-section-title {
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #8a9ab0;
        margin-bottom: 16px;
    }

    /* Submit */
    .btn-submit {
        width: 100%;
        padding: 13px;
        background: #0a57a9;
        color: #fefefe;
        font-family: 'DM Sans', sans-serif;
        font-size: 0.95rem;
        font-weight: 600;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        margin-top: 6px;
        transition: background 0.2s, box-shadow 0.2s, transform 0.2s;
        letter-spacing: 0.02em;
    }

    .btn-submit:hover {
        background: #0d6edb;
        box-shadow: 0 6px 20px rgba(10,87,169,0.28);
        transform: translateY(-1px);
    }

    .btn-submit:active { transform: translateY(0); }

    /* Terms */
    .terms-note {
        font-size: 0.75rem;
        color: #8a9ab0;
        text-align: center;
        margin-top: 14px;
        line-height: 1.5;
    }

    .terms-note a { color: #0a57a9; text-decoration: none; }
    .terms-note a:hover { text-decoration: underline; }

    /* Alert */
    .alert {
        padding: 12px 16px;
        border-radius: 8px;
        font-size: 0.85rem;
        margin-bottom: 20px;
        display: none;
    }

    .alert--error {
        background: #fff0f0;
        border: 1px solid #f5c6c6;
        color: #c0392b;
    }

    .alert--success {
        background: #f0fff6;
        border: 1px solid #b8f0d4;
        color: #1a7a4a;
    }

    /* Login link */
    .register-login {
        text-align: center;
        font-size: 0.875rem;
        color: #6b7a8d;
        margin-top: 20px;
    }

    .register-login a {
        color: #0a57a9;
        font-weight: 600;
        text-decoration: none;
    }

    .register-login a:hover { text-decoration: underline; }

    @media (max-width: 520px) {
        .register-card { padding: 32px 20px; }
        .form-row { grid-template-columns: 1fr; gap: 0; }
    }
</style>

<div class="register-wrap">
    <div class="register-card">

        <!-- Breadcrumb -->
        <div class="register-steps">
            <a href="signup.php" class="register-steps__done">Choose Type</a>
            <span class="register-steps__sep">›</span>
            <span class="register-steps__current">Create Account</span>
        </div>

        <!-- Badge + Title -->
        <div class="register-card__badge">
            <?= $type === 'company' ? '🏢 Company' : '🧑‍💼 Candidate' ?>
        </div>
        <h1 class="register-card__title">Create your account</h1>
        <p class="register-card__sub">
            <?= $type === 'company'
                ? 'Set up your company account to start managing IT projects and hiring.'
                : 'Set up your candidate profile to discover opportunities.' ?>
        </p>

        <!-- Server-side error/success (populated after POST redirect) -->
        <div class="alert alert--error" id="formAlert"></div>

        <!-- FORM -->
        <form id="registerForm" novalidate>
            <input type="hidden" name="account_type" value="<?= htmlspecialchars($type) ?>">

            <?php if ($type === 'candidate'): ?>
                <!-- ── Candidate fields ── -->
                <p class="form-section-title">Personal Information</p>

                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">First Name <span>*</span></label>
                        <input type="text" id="first_name" name="first_name"
                               placeholder="Jane" autocomplete="given-name" required>
                        <span class="field-error" id="first_name_err">Required</span>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name <span>*</span></label>
                        <input type="text" id="last_name" name="last_name"
                               placeholder="Smith" autocomplete="family-name" required>
                        <span class="field-error" id="last_name_err">Required</span>
                    </div>
                </div>

            <?php else: ?>
                <!-- ── Company fields ── -->
                <p class="form-section-title">Company Information</p>

                <div class="form-group">
                    <label for="company_name">Company Name <span>*</span></label>
                    <input type="text" id="company_name" name="company_name"
                           placeholder="Acme Pty Ltd" autocomplete="organization" required>
                    <span class="field-error" id="company_name_err">Required</span>
                </div>

                <div class="form-group">
                    <label for="abn">ABN (Australian Business Number)</label>
                    <input type="text" id="abn" name="abn"
                           placeholder="12 345 678 901" maxlength="14">
                    <span class="field-error" id="abn_err">Enter a valid 11-digit ABN</span>
                </div>

            <?php endif; ?>

            <div class="form-divider"></div>
            <p class="form-section-title">Account Details</p>

            <div class="form-group">
                <label for="email">Email Address <span>*</span></label>
                <input type="email" id="email" name="email"
                       placeholder="you@example.com" autocomplete="email" required>
                <span class="field-error" id="email_err">Enter a valid email</span>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone"
                       placeholder="+61 4xx xxx xxx" autocomplete="tel">
            </div>

            <div class="form-group">
                <label for="password">Password <span>*</span></label>
                <div class="password-wrap">
                    <input type="password" id="password" name="password"
                           placeholder="Min. 8 characters" autocomplete="new-password" required>
                    <button type="button" class="password-toggle" onclick="togglePw('password', this)" aria-label="Show password">👁</button>
                </div>
                <div class="strength-bar"><div class="strength-bar__fill" id="strengthFill"></div></div>
                <span class="strength-label" id="strengthLabel"></span>
                <span class="field-error" id="password_err">Minimum 8 characters required</span>
            </div>

            <div class="form-group">
                <label for="password_confirm">Confirm Password <span>*</span></label>
                <div class="password-wrap">
                    <input type="password" id="password_confirm" name="password_confirm"
                           placeholder="Repeat your password" autocomplete="new-password" required>
                    <button type="button" class="password-toggle" onclick="togglePw('password_confirm', this)" aria-label="Show password">👁</button>
                </div>
                <span class="field-error" id="password_confirm_err">Passwords do not match</span>
            </div>

            <button type="submit" class="btn-submit" id="submitBtn">Create Account</button>
        </form>

        <p class="terms-note">
            By creating an account you agree to our
            <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.
        </p>

        <p class="register-login">
            Already have an account? <a href="login.php">Log in</a>
        </p>
    </div>
</div>

<script>
const type = '<?= $type ?>';

/* ── Password visibility toggle ── */
function togglePw(id, btn) {
    const input = document.getElementById(id);
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    btn.textContent = isHidden ? '🙈' : '👁';
}

/* ── Password strength ── */
document.getElementById('password').addEventListener('input', function () {
    const val = this.value;
    const fill = document.getElementById('strengthFill');
    const label = document.getElementById('strengthLabel');
    let score = 0;
    if (val.length >= 8)              score++;
    if (/[A-Z]/.test(val))            score++;
    if (/[0-9]/.test(val))            score++;
    if (/[^A-Za-z0-9]/.test(val))     score++;

    const levels = [
        { w: '0%',   bg: '',          text: '' },
        { w: '25%',  bg: '#e05555',   text: 'Weak' },
        { w: '50%',  bg: '#f59e0b',   text: 'Fair' },
        { w: '75%',  bg: '#3b9eff',   text: 'Good' },
        { w: '100%', bg: '#22c55e',   text: 'Strong' },
    ];

    fill.style.width      = levels[score].w;
    fill.style.background = levels[score].bg;
    label.textContent     = levels[score].text;
    label.style.color     = levels[score].bg;
});

/* ── ABN formatter (company only) ── */
<?php if ($type === 'company'): ?>
document.getElementById('abn')?.addEventListener('input', function () {
    let v = this.value.replace(/\D/g, '').slice(0, 11);
    if (v.length > 2)  v = v.slice(0,2)  + ' ' + v.slice(2);
    if (v.length > 5)  v = v.slice(0,5)  + ' ' + v.slice(5);
    if (v.length > 9)  v = v.slice(0,9)  + ' ' + v.slice(9);
    this.value = v;
});
<?php endif; ?>

/* ── Client-side validation ── */
function showErr(id, msg) {
    const el = document.getElementById(id + '_err');
    const input = document.getElementById(id);
    if (el)    { el.style.display = 'block'; if (msg) el.textContent = msg; }
    if (input) input.classList.add('error');
}

function clearErr(id) {
    const el = document.getElementById(id + '_err');
    const input = document.getElementById(id);
    if (el)    el.style.display = 'none';
    if (input) input.classList.remove('error');
}

document.getElementById('registerForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    let valid = true;

    // Clear previous errors
    ['first_name','last_name','company_name','abn','email','phone','password','password_confirm']
        .forEach(clearErr);

    // Type-specific validation
    if (type === 'candidate') {
        if (!document.getElementById('first_name')?.value.trim()) { showErr('first_name'); valid = false; }
        if (!document.getElementById('last_name')?.value.trim())  { showErr('last_name');  valid = false; }
    } else {
        if (!document.getElementById('company_name')?.value.trim()) { showErr('company_name'); valid = false; }
        const abn = document.getElementById('abn')?.value.replace(/\s/g,'') || '';
        if (abn && abn.length !== 11) { showErr('abn'); valid = false; }
    }

    // Email
    const email = document.getElementById('email').value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showErr('email'); valid = false; }

    // Password
    const pw  = document.getElementById('password').value;
    const pw2 = document.getElementById('password_confirm').value;
    if (pw.length < 8)  { showErr('password', 'Minimum 8 characters required'); valid = false; }
    if (pw !== pw2)     { showErr('password_confirm', 'Passwords do not match'); valid = false; }

    if (!valid) return;

    // Submit via fetch
    const btn = document.getElementById('submitBtn');
    btn.disabled    = true;
    btn.textContent = 'Creating account…';

    const formData = new FormData(this);

    try {
        const res  = await fetch('register_process.php', { method: 'POST', body: formData });
        const data = await res.json();

        if (data.success) {
            window.location.href = data.redirect || 'index.php';
        } else {
            const alert = document.getElementById('formAlert');
            alert.style.display = 'block';
            alert.textContent   = data.message || 'Something went wrong. Please try again.';
            btn.disabled    = false;
            btn.textContent = 'Create Account';
        }
    } catch (err) {
        const alert = document.getElementById('formAlert');
        alert.style.display = 'block';
        alert.textContent   = 'Network error. Please try again.';
        btn.disabled    = false;
        btn.textContent = 'Create Account';
    }
});
</script>

</body>
</html>
